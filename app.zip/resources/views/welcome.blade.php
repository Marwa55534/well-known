
@extends('layout.app')

@section('content')


  <!--start main wrapper-->
  <main class="main-wrapper d-flex justify-content-center align-items-center">
    <div class="main-content">

        <div class="row d-flex justify-content-center align-items-center">
            <div class="col-lg-12 d-flex justify-content-center align-items-center">
                <img src="{{ asset('assets/images/home.png') }}" width="50%" alt="">
            </div>
        </div>

    </div>
  </main>
  <!--end main wrapper-->

  @endsection
