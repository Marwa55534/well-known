@extends('layout.app')

  <!--start main wrapper-->
  <main class="main-wrapper">
    <div class="main-content">

      <div class="row mb-5">
        <div class="col-12 col-xl-12">
          <div class="card">
            <div class="card-body">
              <div class="add mt-3 mb-3 text-end d-flex justify-content-end">
                <button class="btn btn-primary" data-bs-target="#addservice" data-bs-toggle="modal"> <i class="fas fa-add"></i>  اضافة صاحب الخدمة</button>
              </div>
              <div class="table-responsive text-center">
                @if(session('delete'))
                <div class="alert alert-success">
                    {{ session('delete') }}
                </div>
            @endif
            
            @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
            @endif
                <table id="example2" class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <th>الاسم</th>
                      <th>الوصف</th>
                      <th>الصوره</th>
                      <th>المحافظة</th>
                      <th>المركز</th>
                      <th>الخدمة</th>
                      <th>واتس</th>
                      <th>الفون</th>
                      <th>التحكم</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($subservices as $subservice)
                    <tr>
                      
                      <td>{{ $subservice->title }}</td>
                      <td>{{ $subservice->description }}</td>
                      <td><img src={{ $subservice->image }} width="100px" alt="صورة"></td>
                      <td>{{ $subservice->governorate->name ?? null }}</td>
                      <td>{{ $subservice->centerGovernorate->name ?? null }}</td>
                      <td>{{ $subservice->service->name ?? null }}</td>
                      <td>{{ $subservice->whatsapp }}</td>
                      <td>{{ $subservice->phone }}</td>
                      <td class="d-flex justify-content-center align-items-center">
                        <button type="button" class="btn btn-warning ms-2" data-bs-target="#editquestions" data-bs-toggle="modal" onclick="editService({{ $subservice->id }})"><i class="fas fa-edit"></i></button>
                        <form action="{{ route('delete-sub-services', $subservice->id) }}" method="post" class="m-0">
                          @csrf
                          @method('delete')
                          <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                      </form>
                                          </td>
                    </tr>
                    @empty
                    <td colspan="9">لا يوجد اصحاب خدمات</td>
                      
                    @endforelse
                  
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Add Service Modal -->
      <div class="modal fade" id="addservice" tabindex="-1" aria-labelledby="UserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> اضافة</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              <form action="{{ route('create-sub-services') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="container">
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="title" class="form-control @error('title')is-invalid @enderror" placeholder="أدخل الاسم">
                      @error('title')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                      <input required type="file" name="image" class="form-control @error('image')is-invalid @enderror" accept="image/*">
                      @error('image')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror

                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="description" class="form-control @error('description')is-invalid @enderror" placeholder="أدخل الوصف">
                      @error('description')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                      <select id="service_id" name="service_id" class="form-select" data-placeholder="اختر الخدمة"
                      data-select-all="false" data-max="1">
                      @foreach($services as $service)
                      <option value="{{ $service->id }}">{{ $service->name }}</option>
                  @endforeach
                  
              </select>
                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <select id="governorate_id" name="governorate_id" class="form-select" data-placeholder="اختر محافظة"
                      data-select-all="false" data-max="1">
                      @forelse($governorates as $governorate)
                  <option value={{ $governorate->id }}>{{ $governorate->name }}</option>
                        
                      @empty
                  <option disabled>لا يوجد محافظات</option>
                        
                      @endforelse
                  
                  </select>
                  @error('governorate_id')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                      <select id="center_governorate_id" class="form-select" name="center_governorate_id" data-placeholder="اختر مركز"
                      data-select-all="false" data-max="1">
                      @forelse($centerGovernorates as $centerGovernorate)
                      <option value={{ $centerGovernorate->id }}>{{ $centerGovernorate->name }}</option>
                            
                          @empty
                      <option disabled>لا يوجد مراكز</option>
                            
                          @endforelse
                 </select>
                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="whatsapp" class="form-control @error('whatsapp')is-invalid @enderror" placeholder="أدخل الواتس">
                      @error('whatsapp')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phone" class="form-control @error('phone')is-invalid @enderror" placeholder="أدخل الهاتف">
                      @error('phone')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary w-100">اضافة</button>
                </div>
              </form>
            </div>
           
          </div>
        </div>
      </div>

      <!-- Edit Service Modal -->
      <div class="modal fade" id="editquestions" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> تعديل</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              <form action="{{ route('update-sub-services', ':id') }}" method="POST" id="editServiceForm" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="container">
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="title" class="form-control @error('title')is-invalid @enderror" placeholder="أدخل الاسم">
                      @error('title')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                      <input  type="file" name="image" class="form-control @error('image')is-invalid @enderror" accept="image/*">
                      @error('image')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                  <img required id="imagePreview" src="" alt="Current Image" style="max-width: 100%; margin-top: 10px;">

                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="description" class="form-control @error('description')is-invalid @enderror" placeholder="أدخل الوصف">
                      @error('description')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                      <select id="service" name="service_id" class="form-select" data-placeholder="اختر الخدمة"
                      data-select-all="false" data-max="1">
                      @foreach($services as $service)
                      <option value="{{ $service->id }}">{{ $service->name }}</option>
                  @endforeach
                  
              </select>
              


                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
<select id="governorate_id" name="governorate_id" class="form-select" data-placeholder="اختر محافظة">
    @forelse($governorates as $governorate)
        <option value="{{ $governorate->id }}" 
            {{ isset($subservice) && $subservice->governorate_id == $governorate->id ? 'selected' : '' }}>
            {{ $governorate->name }}
        </option>
    @empty
        <option disabled>لا يوجد محافظات</option>
    @endforelse
</select>


                  @error('governorate_id')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                        
<select id="center_governorate_id" class="form-select" name="center_governorate_id">
    @foreach($centerGovernorates as $center)
        <option value="{{ $center->id }}" 
            {{ (isset($subService) && $subService->center_governorate_id == $center->id) ? 'selected' : '' }}>
            {{ $center->name }}
        </option>
    @endforeach
</select>


                 
                 
                 
                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="whatsapp" class="form-control @error('whatsapp')is-invalid @enderror" placeholder="أدخل الواتس">
                      @error('whatsapp')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phone" class="form-control @error('phone')is-invalid @enderror" placeholder="أدخل الهاتف">
                      @error('phone')
                      <span class="text-danger invalid-feedback">{{ $message }}</span>
                  @enderror
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary w-100">تعديل</button>
                </div>
              </form>
            </div>
           
          </div>
        </div>
      </div>

    </div>
  </main>
  
  
  <!--bootstrap js-->
  @section('scripts')

  <script>
$('#editquestions').on('shown.bs.modal', function () {
    editService(serviceId);
});


$('#editquestions').on('shown.bs.modal', function () {
    editService(serviceId);
});

function editService(serviceId) {
    console.log('Editing Service ID:', serviceId);

    fetch(`/sub-services/${serviceId}/edit`)
        .then(response => response.json())
        .then(data => {
            
            const titleInput = document.querySelector('#editServiceForm input[name="title"]');
            const descriptionInput = document.querySelector('#editServiceForm input[name="description"]');
            const whatsappInput = document.querySelector('#editServiceForm input[name="whatsapp"]');
            const phoneInput = document.querySelector('#editServiceForm input[name="phone"]');
            const serviceIdInput = document.querySelector('#editServiceForm input[name="service_id"]');
            const governorateIdInput = document.querySelector('#editServiceForm input[name="governorate_id"]');
            const centerGovernorateIdInput = document.querySelector('#editServiceForm input[name="center_governorate_id"]');

            if (titleInput) titleInput.value = data.title;
            if (descriptionInput) descriptionInput.value = data.description;
            if (whatsappInput) whatsappInput.value = data.whatsapp;
            if (phoneInput) phoneInput.value = data.phone;
            if (serviceIdInput) serviceIdInput.value = data.service_id;
            if (governorateIdInput) governorateIdInput.value = data.governorate_id;
            if (centerGovernorateIdInput) centerGovernorateIdInput.value = data.center_governorate_id;

            const form = document.querySelector('#editServiceForm');
            if (form) {
                form.action = `/sub-services/${serviceId}`;
            }

            const imagePreview = document.querySelector('#imagePreview');
            if (imagePreview && data.image) {
                imagePreview.src = `/${data.image}`; 
            }
        })
        .catch(error => {
            console.error('Error fetching service data:', error);
        });
}
  
    const currentPage = window.location.pathname.split("/").pop();
  
   
    const navLinks = document.querySelectorAll('.nav-link');
  
    
    navLinks.forEach(link => {
      if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
      }
    });
  </script>
@endsection

 