<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\CenterGovernorate;
use App\Models\Governorate;
use App\Models\Service;
use App\Models\SubService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SubServiceController extends Controller
{
    public function index(Request $request)
    {
        $subservices = SubService::get();
        $services = Service::all();
$governorates = Governorate::all();
$centerGovernorates = CenterGovernorate::all();

        return view('ownerservice',compact('subservices','services', 'governorates', 'centerGovernorates'));

    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image' => 'required|file|mimes:jpg,jpeg,png,gif|max:2048',
            'whatsapp' => 'required|numeric|digits:11|unique:sub_services',
            'phone' => 'required|numeric|digits:11|unique:sub_services',
            'service_id' => 'required|exists:services,id',
            'governorate_id' => 'required|exists:governorates,id',
            'center_governorate_id' => 'required|exists:center_governorates,id',
        ]);
        
        $imagePath = $request->hasFile('image') 
        ? $request->file('image')->store('sub_service_images', 'public') 
        : null;
        $subService = SubService::create([
            'title' => $request->title,
            'description' => $request->description,
           
            'whatsapp' => $request->whatsapp,
            'phone' => $request->phone,
            'service_id' => $request->service_id,
            'image' => $imagePath,
            'governorate_id' => $request->governorate_id,
            'center_governorate_id' => $request->center_governorate_id,

        ]);
        // $subService->load(['governorate', 'centerGovernorate','services']);


        return redirect()->route('sub-services')->with('success', 'تمت اضافة صاحب الخدمة بنجاح');
    }



    

    public function editSubService($id)
{
    $subService = SubService::find($id);

    if (!$subService) {
        return response()->json(['message' => 'SubService not found'], 404);
    }
    
    

    return response()->json([
        'id' => $subService->id,
        'title' => $subService->title,
        'description' => $subService->description,
        'whatsapp' => $subService->whatsapp,
        'phone' => $subService->phone,
        'service_id' => $subService->service_id,
        'image' => $subService->image, 
        'governorate_id' => $subService->governorate_id,
        'center_governorate_id' => $subService->center_governorate_id,
        
    ]);
}

public function updateSubService(Request $request, $id)
{
    $request->validate([
        'title' => 'sometimes|string|max:255',
        'description' => 'sometimes|string',
        'image' => 'sometimes|file|mimes:jpg,jpeg,png,gif|max:2048',
        'whatsapp' => 'sometimes|string',
        'phone' => 'sometimes|string',
        'service_id' => 'sometimes|exists:services,id',
        'governorate_id' => 'sometimes|exists:governorates,id',
        'center_governorate_id' => 'sometimes|exists:center_governorates,id',
    ]);

    $subService = SubService::find($id);
    if (!$subService) {
        return response()->json(['message' => 'SubService not found'], 404);
    }

    if ($request->hasFile('image')) {
        if ($subService->image && Storage::exists('public/' . $subService->image)) {
            Storage::delete('public/' . $subService->image);
        }

        $imagePath = $request->file('image')->store('sub-services-images', 'public');
        $subService->image = $imagePath;
    }

    $subService->update($request->except('image'));

    return redirect()->route('sub-services')->with('success', 'تم تحديث صاحب الخدمة بنجاح');
}





public function destroy($id)
{
    $subService = SubService::find($id);
    if (!$subService) {
        return redirect()->route('sub-services')->with('error', 'خطأ في حذف صاحب الخدمة');
    }

    if ($subService->image && Storage::exists('public/' . $subService->image)) {
        Storage::delete('public/' . $subService->image);
    }

    $subService->delete();

    return redirect()->route('sub-services')->with('error', 'تم  حذف صاحب الخدمة');
}

}
