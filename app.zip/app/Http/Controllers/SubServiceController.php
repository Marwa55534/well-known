<?php

namespace App\Http\Controllers;

use App\Models\SubService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
class SubServiceController extends Controller
{
    public function index(Request $request)
    {
        $query = SubService::query();

        if ($request->has('service_id')) {
            $query->where('service_id', $request->service_id);
        }

        $subServices = $query->get();

        if ($subServices->isEmpty()) {
            return $this->formatResponse(null, 'SubServices not found', false, 404);
        }
        foreach ($subServices as $subService) {
            $subService->image = !empty($subService->image) ? url($subService->image) : null;
            
        }

        return $this->formatResponse($subServices, 'SubServices retrieved successfully');
    }
    public function show($id)
    {
        $subService = SubService::find($id);
        if (!$subService) {
            return $this->formatResponse(null, 'SubService not found', false, 404);
        }
        
$subService->image = !empty($subService->image) ? url($subService->image) : null;
        return $this->formatResponse($subService, 'SubService retrieved successfully');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image' => 'required|file|mimes:jpg,jpeg,png,gif|max:2048',
            'whatsapp' => 'required|numeric|digits:11|unique:sub_services',
            'phone' => 'required|numeric|digits:11|unique:sub_services',
            'service_id' => 'required|exists:services,id',
            'governorate_id' => 'required|exists:governorates,id',
            'center_governorate_id' => 'required|exists:center_governorates,id',
        ]);

        $imagePath = $request->file('image')->store('sub_service_images', 'public');

        $subService = SubService::create([
            'title' => $request->title,
            'description' => $request->description,
           
            'whatsapp' => $request->whatsapp,
            'phone' => $request->phone,
            'service_id' => $request->service_id,
            'image' => $imagePath,
            'governorate_id' => $request->governorate_id,
            'center_governorate_id' => $request->center_governorate_id,

        ]);
        $subService->load(['governorate', 'centerGovernorate']);


        return $this->formatResponse($subService, 'Sub-service created successfully', true, 201);
    }


    public function update(Request $request, $id)
    {
        $subService = SubService::findOrFail($id);

        $request->validate([
            'title' => 'sometimes|string|max:255',
            'description' => 'sometimes|string',
           
            'image' => 'sometimes|string',
            'whatsapp' => 'sometimes|string',
            'phone' => 'sometimes|string',
            'service_id' => 'sometimes|exists:services,id',
            'governorate_id' => 'sometimes|exists:governorates,id',
            'center_governorate_id' => 'sometimes|exists:center_governorates,id',
        ]);

        $subService->update($request->all());
        return $this->formatResponse($subService, 'Sub-service updated successfully');
    }

    public function destroy($id)
    {
        $subService = SubService::find($id);
        if (!$subService) {
            return $this->formatResponse(null, 'SubService not found', false, 404);
        }
        $subService->delete();
        return $this->formatResponse(null, 'Sub-service deleted successfully', true, 200);
    }
}
