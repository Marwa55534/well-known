<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubService extends Model
{
    //
    protected $fillable = ['title', 'description', 
     'image', 'whatsapp', 'phone', 'service_id','governorate_id',
    'center_governorate_id',];

    public function service()
    {
        return $this->belongsTo(Service::class);
    }
    public function governorate()
    {
        return $this->belongsTo(Governorate::class);
    }

    public function centerGovernorate()
    {
        return $this->belongsTo(CenterGovernorate::class);
    }
}
