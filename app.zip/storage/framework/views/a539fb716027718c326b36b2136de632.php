<?php $__env->startSection('content'); ?>
  <!--start main wrapper-->
  <main class="main-wrapper">
    <div class="main-content">

      <div class="row mb-5">
        <div class="col-12 col-xl-12">
          <div class="card">
            <div class="card-body">
                <div class="add mt-3 mb-3 text-end d-flex justify-content-end">
                    <button class="btn btn-primary" data-bs-target="#add" data-bs-toggle="modal"> <i class="fas fa-add"></i>اضافة مركز</button>
                  </div>
              <div class="table-responsive text-center">
                <?php if(session('delete')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('delete')); ?>

                </div>
            <?php endif; ?>
            
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
                <table id="example2" class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      
                     
                      <th>المركز</th>
                      <th>المحافظة</th>

                      <th>التحكم</th>

                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $centergovernorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centergovernorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      
                        <td><?php echo e($centergovernorate->name); ?></td>
                        <td><?php echo e($centergovernorate->governorate->name); ?></td>

                       
                        <td class="d-flex justify-content-center align-items-center">  
                            <button type="button" class="btn btn-warning ms-2" data-bs-target="#addservic" data-bs-toggle="modal" onclick="editCenterGovernorate(<?php echo e($centergovernorate->id); ?>)"><i class="fas fa-edit"></i></button>
  
                          <form action="<?php echo e(route('delete-center-governate', $centergovernorate->id)); ?>" method="post" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="button" class="btn btn-danger" onclick="deleteCeterGovernate(<?php echo e($centergovernorate->id); ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                          
                        </form>
                                          </td>
                      </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <td colspan="3">لا يوجد مراكز</td>
                        
                    <?php endif; ?>
                    
                   
                   
                    
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      

     
      <div class="modal fade" id="addservic" tabindex="-1" aria-labelledby="UserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> تعديل</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              
                <form action="<?php echo e(route('update-center-governate', ':id')); ?>" method="POST" id="editServiceForm">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>               
                     <div class="container">
                    <div class="row my-4">
                     
                        <div class="col-md-6">
                  
                                <input required type="text" name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="أدخل المركز ">
                        </div>
                        <div class="col-md-6">
                  
                        <select id="governorates" name="governorate_id" class="form-select" data-placeholder="اختر محافظة"
                      data-select-all="false" data-max="1">
                      <?php $__empty_1 = true; $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value=<?php echo e($governorate->id); ?>><?php echo e($governorate->name); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <option disabled>لا توجد محافظات</option>
                      <?php endif; ?>
                  </select>
                    </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary w-100">تعديل</button>
                  </div>
              </form>
            </div>
            
          </div>
        </div>
      </div>
      <div class="modal fade" id="add" tabindex="-1" aria-labelledby="UserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> اضافة</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              
                <form action="<?php echo e(route('create-center-governate')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                <div class="container">
                    <div class="row my-4">
                        <div class="col-md-6">
                  
                                <input required type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="أدخل المركز " name="name">
                        </div>

                        <div class="col-md-6">
                  
                          <select id="governorate_id" name="governorate_id" class="form-select" data-placeholder="اختر محافظة"
                          data-select-all="false" data-max="1">
                          
                          <?php $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value=<?php echo e($governorate->id); ?>><?php echo e($governorate->name); ?></option>
                            
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     
                      </select>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary w-100">اضافة</button>
                  </div>
              </form>
            </div>
           
          </div>
        </div>
      </div>
     


    </div>
  </main>
  <!--end main wrapper-->

  <!--start overlay-->
  <div class="overlay btn-toggle"></div>
  <!--end overlay-->

  <?php $__env->stopSection(); ?>

  
  <!--bootstrap js-->
  <?php $__env->startSection('scripts'); ?>
  <script>
     function deleteCeterGovernate(id) {
    if (confirm('هل أنت متأكد من حذف هذا المركز؟')) {
      fetch(`/center-governate/${id}`, {
    method: 'DELETE',
    headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
    }
})

        .then(response => {
          window.location.href = '/center-governate';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('حدث خطأ أثناء محاولة الحذف');
        });
    }
}


function editCenterGovernorate(centergovernorate) {
    console.log('Editing Governorate ID:', centergovernorate);

    fetch(`/center-governate/${centergovernorate}/edit`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
    document.querySelector('#editServiceForm input[name="name"]').value = data.name;
    const form = document.querySelector('#editServiceForm');
    form.action = `/center-governate/${data.id}`; 
})

        .catch(error => {
            console.error('Error fetching service data:', error);
        });
}
  
    const currentPage = window.location.pathname.split("/").pop();
  
   
    const navLinks = document.querySelectorAll('.nav-link');
  
    
    navLinks.forEach(link => {
      if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
      }
    });
  </script>
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servicefromhere/public_html/resources/views/centergovernorates.blade.php ENDPATH**/ ?>