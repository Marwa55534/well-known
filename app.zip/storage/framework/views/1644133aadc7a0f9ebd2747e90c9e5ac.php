

  <!--start main wrapper-->
  <main class="main-wrapper">
    <div class="main-content">

      <div class="row mb-5">
        <div class="col-12 col-xl-12">
          <div class="card">
            <div class="card-body">
              <div class="add mt-3 mb-3 text-end d-flex justify-content-end">
                <button class="btn btn-primary" data-bs-target="#addservice" data-bs-toggle="modal"> <i class="fas fa-add"></i>  اضافة صاحب الخدمة</button>
              </div>
              <div class="table-responsive text-center">
                <?php if(session('delete')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('delete')); ?>

                </div>
            <?php endif; ?>
            
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
                <table id="example2" class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      <th>الاسم</th>
                      <th>الوصف</th>
                      <th>الصوره</th>
                      <th>المحافظة</th>
                      <th>المركز</th>
                      <th>الخدمة</th>
                      <th>واتس</th>
                      <th>الفون</th>
                      <th>التحكم</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $subservices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      
                      <td><?php echo e($subservice->title); ?></td>
                      <td><?php echo e($subservice->description); ?></td>
                      <td><img src=<?php echo e($subservice->image); ?> width="100px" alt="صورة"></td>
                      <td><?php echo e($subservice->governorate->name ?? null); ?></td>
                      <td><?php echo e($subservice->centerGovernorate->name ?? null); ?></td>
                      <td><?php echo e($subservice->service->name ?? null); ?></td>
                      <td><?php echo e($subservice->whatsapp); ?></td>
                      <td><?php echo e($subservice->phone); ?></td>
                      <td class="d-flex justify-content-center align-items-center">
                        <button type="button" class="btn btn-warning ms-2" data-bs-target="#editquestions" data-bs-toggle="modal" onclick="editService(<?php echo e($subservice->id); ?>)"><i class="fas fa-edit"></i></button>
                        <form action="<?php echo e(route('delete-sub-services', $subservice->id)); ?>" method="post" class="m-0">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('delete'); ?>
                          <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                      </form>
                                          </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td colspan="9">لا يوجد اصحاب خدمات</td>
                      
                    <?php endif; ?>
                  
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Add Service Modal -->
      <div class="modal fade" id="addservice" tabindex="-1" aria-labelledby="UserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> اضافة</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              <form action="<?php echo e(route('create-sub-services')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="container">
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الاسم">
                      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                      <input required type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*">
                      <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الوصف">
                      <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                      <select id="service_id" name="service_id" class="form-select" data-placeholder="اختر الخدمة"
                      data-select-all="false" data-max="1">
                      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
              </select>
                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <select id="governorate_id" name="governorate_id" class="form-select" data-placeholder="اختر محافظة"
                      data-select-all="false" data-max="1">
                      <?php $__empty_1 = true; $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <option value=<?php echo e($governorate->id); ?>><?php echo e($governorate->name); ?></option>
                        
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <option disabled>لا يوجد محافظات</option>
                        
                      <?php endif; ?>
                  
                  </select>
                  <?php $__errorArgs = ['governorate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                      <select id="center_governorate_id" class="form-select" name="center_governorate_id" data-placeholder="اختر مركز"
                      data-select-all="false" data-max="1">
                      <?php $__empty_1 = true; $__currentLoopData = $centerGovernorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $centerGovernorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <option value=<?php echo e($centerGovernorate->id); ?>><?php echo e($centerGovernorate->name); ?></option>
                            
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                      <option disabled>لا يوجد مراكز</option>
                            
                          <?php endif; ?>
                 </select>
                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="whatsapp" class="form-control <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الواتس">
                      <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الهاتف">
                      <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary w-100">اضافة</button>
                </div>
              </form>
            </div>
           
          </div>
        </div>
      </div>

      <!-- Edit Service Modal -->
      <div class="modal fade" id="editquestions" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> تعديل</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              <form action="<?php echo e(route('update-sub-services', ':id')); ?>" method="POST" id="editServiceForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="container">
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="title" class="form-control <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الاسم">
                      <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                      <input  type="file" name="image" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" accept="image/*">
                      <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  <img required id="imagePreview" src="" alt="Current Image" style="max-width: 100%; margin-top: 10px;">

                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الوصف">
                      <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                      <select id="service" name="service_id" class="form-select" data-placeholder="اختر الخدمة"
                      data-select-all="false" data-max="1">
                      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
              </select>
              


                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
<select id="governorate_id" name="governorate_id" class="form-select" data-placeholder="اختر محافظة">
    <?php $__empty_1 = true; $__currentLoopData = $governorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <option value="<?php echo e($governorate->id); ?>" 
            <?php echo e(isset($subservice) && $subservice->governorate_id == $governorate->id ? 'selected' : ''); ?>>
            <?php echo e($governorate->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <option disabled>لا يوجد محافظات</option>
    <?php endif; ?>
</select>


                  <?php $__errorArgs = ['governorate_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        
<select id="center_governorate_id" class="form-select" name="center_governorate_id">
    <?php $__currentLoopData = $centerGovernorates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($center->id); ?>" 
            <?php echo e((isset($subService) && $subService->center_governorate_id == $center->id) ? 'selected' : ''); ?>>
            <?php echo e($center->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>


                 
                 
                 
                    </div>
                  </div>
                  <div class="row my-4">
                    <div class="col-md-6">
                      <input required type="text" name="whatsapp" class="form-control <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الواتس">
                      <?php $__errorArgs = ['whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                      <input required type="text" name="phone" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الهاتف">
                      <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
                <div class="modal-footer">
                  <button type="submit" class="btn btn-primary w-100">تعديل</button>
                </div>
              </form>
            </div>
           
          </div>
        </div>
      </div>

    </div>
  </main>
  
  
  <!--bootstrap js-->
  <?php $__env->startSection('scripts'); ?>

  <script>
$('#editquestions').on('shown.bs.modal', function () {
    editService(serviceId);
});


$('#editquestions').on('shown.bs.modal', function () {
    editService(serviceId);
});

function editService(serviceId) {
    console.log('Editing Service ID:', serviceId);

    fetch(`/sub-services/${serviceId}/edit`)
        .then(response => response.json())
        .then(data => {
            
            const titleInput = document.querySelector('#editServiceForm input[name="title"]');
            const descriptionInput = document.querySelector('#editServiceForm input[name="description"]');
            const whatsappInput = document.querySelector('#editServiceForm input[name="whatsapp"]');
            const phoneInput = document.querySelector('#editServiceForm input[name="phone"]');
            const serviceIdInput = document.querySelector('#editServiceForm input[name="service_id"]');
            const governorateIdInput = document.querySelector('#editServiceForm input[name="governorate_id"]');
            const centerGovernorateIdInput = document.querySelector('#editServiceForm input[name="center_governorate_id"]');

            if (titleInput) titleInput.value = data.title;
            if (descriptionInput) descriptionInput.value = data.description;
            if (whatsappInput) whatsappInput.value = data.whatsapp;
            if (phoneInput) phoneInput.value = data.phone;
            if (serviceIdInput) serviceIdInput.value = data.service_id;
            if (governorateIdInput) governorateIdInput.value = data.governorate_id;
            if (centerGovernorateIdInput) centerGovernorateIdInput.value = data.center_governorate_id;

            const form = document.querySelector('#editServiceForm');
            if (form) {
                form.action = `/sub-services/${serviceId}`;
            }

            const imagePreview = document.querySelector('#imagePreview');
            if (imagePreview && data.image) {
                imagePreview.src = `/${data.image}`; 
            }
        })
        .catch(error => {
            console.error('Error fetching service data:', error);
        });
}
  
    const currentPage = window.location.pathname.split("/").pop();
  
   
    const navLinks = document.querySelectorAll('.nav-link');
  
    
    navLinks.forEach(link => {
      if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
      }
    });
  </script>
<?php $__env->stopSection(); ?>

 
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servicefromhere/public_html/resources/views/ownerservice.blade.php ENDPATH**/ ?>