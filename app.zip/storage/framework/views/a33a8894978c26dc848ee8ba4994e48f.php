


<?php $__env->startSection('content'); ?>


  <!--start main wrapper-->
  <main class="main-wrapper d-flex justify-content-center align-items-center">
    <div class="main-content">

        <div class="row d-flex justify-content-center align-items-center">
            <div class="col-lg-12 d-flex justify-content-center align-items-center">
                <img src="<?php echo e(asset('assets/images/home.png')); ?>" width="50%" alt="">
            </div>
        </div>

    </div>
  </main>
  <!--end main wrapper-->

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servicefromhere/public_html/resources/views/welcome.blade.php ENDPATH**/ ?>