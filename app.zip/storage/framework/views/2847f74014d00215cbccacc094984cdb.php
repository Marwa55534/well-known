<?php $__env->startSection('content'); ?>


  <!--start main wrapper-->
  <main class="main-wrapper">
    <div class="main-content">

      <div class="row mb-5">
        <div class="col-12 col-xl-12">
          <div class="card">
            <div class="card-body">
                <div class="add mt-3 mb-3 text-end d-flex justify-content-end">
                    <button class="btn btn-primary" data-bs-target="#addservice" data-bs-toggle="modal"> <i class="fas fa-add"></i>  اضافة سؤال و اجابة</button>
                  </div>
              <div class="table-responsive text-center">
                <?php if(session('delete')): ?>
    <div class="alert alert-success">
        <?php echo e(session('delete')); ?>

    </div>
<?php endif; ?>

<?php if(session('success')): ?>
<div class="alert alert-success">
    <?php echo e(session('success')); ?>

</div>
<?php endif; ?>
                <table id="example2" class="table table-striped table-bordered">
                  <thead>
                    <tr>
                      
                      <th>السؤال</th>
                      <th>الاجابة</th>
                      <th>التحكم</th>

                    </tr>
                  </thead>
                  <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                      <td><?php echo e($question->question); ?></td>
                      <td><?php echo e($question->answer); ?></td>
                     
                      <td class="d-flex justify-content-center align-items-center">  
                        <button type="button" class="btn btn-warning ms-2" data-bs-target="#editquestions" data-bs-toggle="modal" onclick="editService(<?php echo e($question->id); ?>)"><i class="fas fa-edit"></i></button>
                  <form action="<?php echo e(route('delete-questions', $question->id)); ?>" method="post" class="m-0">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?> <!-- Cleaner syntax for delete method -->
                    <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                </form>
                                   </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <td colspan="3">لا يوجد أسئلة</td>

                    <?php endif; ?>
                    
                   
                   
                    
                    
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>

      

      <div class="modal fade" id="addservice" tabindex="-1" aria-labelledby="UserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> اضافة</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              
              <form action="<?php echo e(route('create-questions')); ?>" method="POST">
                <?php echo csrf_field(); ?> 
                <div class="container">
                    <div class="row my-4">
                        <div class="col-md-12">
                            <input required type="text" name="question" class="form-control <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل السؤال" required>
                            <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row my-4">
                        <div class="col-md-12">
                            <input required type="text" name="answer" class="form-control <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="أدخل الاجابة" required>
                            <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row my-4">
                       

                        <div class="modal-footer">
                          <button type="submit" class="btn btn-primary w-100">اضافة</button>
                        </div>

                    </div>
                </div>
            </form>
            
            </div>
           
          </div>
        </div>
      </div>
      
      <div class="modal fade" id="editquestions" tabindex="-1" aria-labelledby="UserModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="UserModalLabel"> تعديل</h5>
              <div class="text-start">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
              </div>
            </div>
            <div class="modal-body">
              
              <form action="<?php echo e(route('update-questions', ':id')); ?>" method="POST" id="editServiceForm">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="container">
                  <div class="row my-4">
                      <div class="col-md-12">
                
                              <input required type="text" class="form-control <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="أدخل السؤال " name="question">

                              <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                    
                  </div>
                  <div class="row my-4">
                      <div class="col-md-12">
                
                        <input required type="text" class="form-control <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"  placeholder="أدخل الاجابة " name="answer">
                        <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                      </div>
                   
                  </div>
                 
              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary w-100">تعديل</button>
              </div>
              </form>
            </div>
            
          </div>
        </div>
      </div>

    </div>
  </main>
  <!--end main wrapper-->

  <!--start overlay-->
  <?php $__env->startSection('scripts'); ?>

  <script>

function editService(serviceId) {
    console.log('Editing Service ID:', serviceId);

    fetch(`/questions/${serviceId}/edit`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            document.querySelector('#editServiceForm input[name="question"]').value = data.question;
            document.querySelector('#editServiceForm input[name="answer"]').value = data.answer;

            document.querySelector('#editServiceForm').action = `/questions/${serviceId}`;
        })
        .catch(error => {
            console.error('Error fetching service data:', error);
        });
}


  
    const currentPage = window.location.pathname.split("/").pop();
  
   
    const navLinks = document.querySelectorAll('.nav-link');
  
    
    navLinks.forEach(link => {
      if (link.getAttribute('href') === currentPage) {
        link.classList.add('active');
      }
    });
  </script>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/servicefromhere/public_html/resources/views/questions.blade.php ENDPATH**/ ?>